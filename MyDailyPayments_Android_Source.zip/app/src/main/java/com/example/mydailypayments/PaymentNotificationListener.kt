package com.example.mydailypayments
import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

class PaymentNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val text = "$title $body"
        val lower = text.lowercase(Locale.getDefault())
        if (listOf("paid", "payment", "debited", "sent", "transferred", "successful", "txn").none { lower.contains(it) }) return
        if (listOf("received", "credited", "refund", "cashback").any { lower.contains(it) }) return
        val amountRegex = Regex("(?:₹|rs\\.?\\s?|inr\\s?)([0-9,]+(?:\\.[0-9]{1,2})?)", RegexOption.IGNORE_CASE)
        val amount = amountRegex.find(text)?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: return
        if (amount <= 0) return
        val payment = Payment(amount = amount, merchant = title.ifBlank { sbn.packageName }.take(100),
            method = "UPI / notification", note = body.take(250), timestamp = sbn.postTime, source = "notification")
        CoroutineScope(Dispatchers.IO).launch { runCatching { PaymentStore().add(payment) } }
    }
}
