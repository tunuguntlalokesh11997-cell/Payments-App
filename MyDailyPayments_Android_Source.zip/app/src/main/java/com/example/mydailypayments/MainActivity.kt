package com.example.mydailypayments
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaterialTheme { PaymentHome() } } }
}
@Composable fun PaymentHome() {
    val context = LocalContext.current
    val store = remember { PaymentStore() }
    val scope = rememberCoroutineScope()
    var payments by remember { mutableStateOf<List<Payment>>(emptyList()) }
    var error by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    fun refresh() { scope.launch { loading = true; try { payments = store.today(); error = "" } catch (e: Exception) { error = e.localizedMessage ?: "Could not load cloud data" }; loading = false } }
    LaunchedEffect(Unit) { refresh() }
    val total = payments.sumOf { it.amount }
    Scaffold(floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }) { Text("+") } }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("My Daily Payments", style = MaterialTheme.typography.headlineMedium)
                Text(SimpleDateFormat("EEEE, dd MMM yyyy", Locale.getDefault()).format(Date()))
            }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) {
                Text("Total spent today", style = MaterialTheme.typography.titleMedium)
                Text("₹${"%.2f".format(total)}", style = MaterialTheme.typography.headlineLarge)
                Text("${payments.size} transactions")
            } } }
            item {
                Button(onClick = { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Enable automatic payment notifications") }
                Text("Grant Notification Access in Android Settings. Only readable payment notifications can be detected.")
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Today's transactions", style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { refresh() }) { Text("Refresh") }
                }
                if (loading) CircularProgressIndicator()
                if (error.isNotBlank()) Text("Cloud sync: $error", color = MaterialTheme.colorScheme.error)
                if (!loading && payments.isEmpty()) Text("No payments yet. Tap + to add your first payment.")
            }
            items(payments, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(p.merchant, style = MaterialTheme.typography.titleMedium)
                        Text("${p.category} • ${p.method}")
                        Text(SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(p.timestamp)), style = MaterialTheme.typography.bodySmall)
                    }
                    Text("-₹${"%.2f".format(p.amount)}", style = MaterialTheme.typography.titleMedium)
                } }
            }
        }
    }
    if (showAdd) AddPaymentDialog(onDismiss = { showAdd = false }, onSave = { amount, merchant, category, method, note ->
        scope.launch { try { store.add(Payment(amount = amount, merchant = merchant, category = category, method = method, note = note)); showAdd = false; refresh() }
            catch (e: Exception) { error = e.localizedMessage ?: "Save failed" } }
    })
}
@Composable fun AddPaymentDialog(onDismiss: () -> Unit, onSave: (Double, String, String, String, String) -> Unit) {
    var amount by remember { mutableStateOf("") }; var merchant by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Other") }; var method by remember { mutableStateOf("Cash") }; var note by remember { mutableStateOf("") }
    val categories = listOf("Food", "Travel", "Fuel", "Shopping", "Bills", "Health", "Transfer", "Other")
    val methods = listOf("Cash", "UPI", "Card", "Bank transfer")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add payment") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(amount, { amount = it }, label = { Text("Amount (₹)") })
            OutlinedTextField(merchant, { merchant = it }, label = { Text("Paid to / description") })
            Text("Category")
            categories.chunked(4).forEach { group -> Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                group.forEach { FilterChip(selected = category == it, onClick = { category = it }, label = { Text(it) }) }
            } }
            Text("Payment method")
            methods.forEach { FilterChip(selected = method == it, onClick = { method = it }, label = { Text(it) }) }
            OutlinedTextField(note, { note = it }, label = { Text("Note (optional)") })
        }
    }, confirmButton = { TextButton(onClick = { val v = amount.toDoubleOrNull(); if (v != null && v > 0 && merchant.isNotBlank()) onSave(v, merchant, category, method, note) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
