package com.example.mydailypayments
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class PaymentStore {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    suspend fun ensureUser() { if (auth.currentUser == null) auth.signInAnonymously().await() }
    suspend fun add(payment: Payment) {
        ensureUser()
        val ref = db.collection("users").document(auth.currentUser!!.uid).collection("payments").document()
        ref.set(payment.copy(id = ref.id)).await()
    }
    suspend fun today(): List<Payment> {
        ensureUser()
        val start = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val end = start + 24L * 60 * 60 * 1000
        return db.collection("users").document(auth.currentUser!!.uid).collection("payments")
            .whereGreaterThanOrEqualTo("timestamp", start).whereLessThan("timestamp", end)
            .get().await().documents.mapNotNull { it.toObject(Payment::class.java) }.sortedByDescending { it.timestamp }
    }
}
