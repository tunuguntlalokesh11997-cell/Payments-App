package com.example.mydailypayments
data class Payment(
    val id: String = "", val amount: Double = 0.0, val merchant: String = "",
    val category: String = "Other", val method: String = "UPI", val note: String = "",
    val timestamp: Long = System.currentTimeMillis(), val source: String = "manual"
)
