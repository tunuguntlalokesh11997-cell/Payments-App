# My Daily Payments — Android source project

Android Kotlin + Jetpack Compose starter with manual entries, best-effort notification-based payment capture, anonymous Firebase Authentication and Cloud Firestore.

## Limitations
- Automatic capture uses Android Notification Access, not bank/SMS scraping. It only parses notifications exposed in readable text with a recognizable rupee amount.
- Notification wording differs by app and bank; it may miss transactions. Add missed items manually.
- It does not initiate payments, access UPI PINs, or read bank credentials.
- Firebase Spark has free quotas, subject to current Firebase terms; usage beyond quotas may require billing.
- This is source code, not a prebuilt APK. Build it with Android Studio.

## Configure Firebase
1. Create a project at https://console.firebase.google.com/.
2. Add an Android app with package name `com.example.mydailypayments`.
3. Download `google-services.json` and put it inside the `app/` folder.
4. Firebase Console > Authentication > Sign-in method: enable **Anonymous**.
5. Create a Cloud Firestore database.
6. Publish these Firestore rules (each user can access only their own records):

```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/payments/{paymentId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

Never use open rules such as `allow read, write: if true`.

## Build and install
1. Install Android Studio on a computer and open this project folder.
2. Install Android SDK 35 when prompted and use JDK 17.
3. Add `google-services.json` to `app/` and let Gradle sync finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer it to your Android phone and install it. Allow installation from that source if Android asks.

## Enable automatic tracking
1. Open My Daily Payments.
2. Tap **Enable automatic payment notifications**.
3. Find My Daily Payments in Android Notification Access settings and enable it.
4. Keep notifications enabled for the payment apps you want to track.
5. Make a small test payment and check whether it appears. If it does not, enter it manually.

Notification Access can expose notification content from apps you allow Android to notify. Enable it only if comfortable with that privacy trade-off. Captured transaction details are saved to your Firebase user's private collection.

## Current feature scope
- Manual cash, UPI, card and bank-transfer entries.
- Automatic notification parser for common debit wording and rupee amount formats.
- Today's total and transaction list.
- Editing/deleting, duplicate detection, monthly/category charts, CSV export, budgets, sign-in recovery and robust app-specific parsers are not included yet.
- Anonymous Firebase identity is tied to the app installation; add a permanent sign-in/recovery flow before relying on cross-device recovery.
